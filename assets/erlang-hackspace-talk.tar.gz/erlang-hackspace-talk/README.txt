Richard Jones
rj@metabrew.com

Hackspace talk example code.

The interesting file in the mochiweb demo project was:
 demo/src/demo_web.erl

Run make in mochiweb-svn/ and demo/ if you want to try it.

